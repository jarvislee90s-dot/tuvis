/**
 * 本机双向身份授权（T06 插件半区）。
 *
 * 插件读兔维斯发布的 rendezvous（`TUVIS_DSH_STATE_DIR/rendezvous.json`，只含
 * 随机 IPC 地址/协议代际/进程身份/Rust 公钥）**主动连接**；以 Node 内置 crypto
 * 做 Ed25519 签名挑战（与 Rust 侧 ed25519-dalek 同曲线同消息字节）。首次绑定 =
 * TOFU + 人工确认 + 两端核对码：用户在兔维斯 UI 批准前，本侧**不兑换、不交付**
 * 任何凭据材料；撤权后停止交付新凭据（直到显式重置身份）。
 *
 * 数据根（R10 统一）：`TUVIS_DSH_STATE_DIR` **就是**状态目录（两端同名同义，
 * Rust 侧同一解析口径）；未设则回落 `~/.tuvis/dsh`。本模块**不读** `TUVIS_HOME`
 * （那是 Rust debug 构建的数据根旋钮，插件猜它会与 release 行为分裂），也不再有
 * `TUVIS_DSH_RENDEZVOUS` 私有覆盖——路径推导在 index.ts 的 deriveRendezvousPath。
 *
 * 身份存储假设（生产接线处，G1 核对）：[`BindingStorage`] 的生产实现落
 * profile 作用域目录（`$DSH_HOME|~/.dsh`/profiles/desktop/tuvis-remote/），
 * 0600 等价权限；本模块不管路径推导，只消费注入的存储面。
 */
import { BINDING_PROTOCOL } from "./types.js";
export { BINDING_PROTOCOL };
/** rendezvous 记录（与 Rust `RendezvousRecord` 逐字段对应；非敏感）。 */
export interface Rendezvous {
    bindingProtocol: number;
    address: string;
    hostId: string;
    /** 十进制字符串（u64 全域超出 JS 安全整数）。 */
    epoch: string;
    processIdentity: {
        platform: string;
        pid: number;
        startedAtMs: number;
        executable: string;
    };
    publicKeySpki: string;
    /**
     * 停用标记（H05 审查 I3 交接）：实例域上线时把仍在场的 legacy 记录改写为
     * `true`——候选读取据此忽略，同宿主 PID 不再双匹配停摆。缺席（旧记录）= false。
     */
    retired?: boolean;
}
export interface RendezvousReader {
    read(): Promise<Rendezvous | null>;
}
/** 插件身份存储（profile 作用域；0600 等价权限由实现保证）。 */
export interface BindingStorage {
    read(): Promise<string | null>;
    write(data: string): Promise<void>;
    scope?(): BindingStorage;
    matchesRendezvous?(rv: Rendezvous): boolean;
}
/** 官方 API Cookie 兑换（薄注入；真实 /connect 在宿主内）。 */
export interface CookieExchange {
    exchange(): Promise<string>;
}
/** 传输抽象（见 ./ipc.js；测试注入假传输）。 */
export interface IpcConnection {
    send(frame: string): Promise<void>;
    recv(): Promise<string>;
    close(): void;
    readonly closed: boolean;
}
export interface IpcTransport {
    connect(address: string): Promise<IpcConnection>;
}
export interface HomeBinding {
    homeRoot: string;
    hostPid: number;
    hostStartedAtMs: number;
}
export interface BindingChallengeMessage {
    bindingProtocol: number;
    /** [Rust 公钥摘要, 客户端公钥摘要]（SHA-256 hex）。 */
    keyDigests: [string, string];
    nonce: string;
    hostId: string;
    /** 十进制字符串（跨 JS 精度）。 */
    epoch: string;
    expiry: number;
    homeBinding?: HomeBinding;
}
/** 被签字节（紧凑 UTF-8 JSON；对象字面量插入序 = wire 字段序，不许改动）。 */
export declare function signingBytes(msg: BindingChallengeMessage): Buffer;
export interface HelloFrame {
    type: "hello";
    homeBinding: HomeBinding;
    bindingProtocol: number;
    publicKeySpki: string;
    executable: string;
    pid: number;
    startedAtMs: number;
    hostId: string;
    epoch: string;
    nonce: string;
    expiry: number;
    signature: string;
}
export interface CredentialFrame {
    type: "credential";
    bindingId: string;
    /**
     * **API 凭据**（`/connect?interactions=answer` 的 302 set-cookie，payload
     * `version: 2` + operator id）。只够开 `/api/remote.mux` 这条 Peer 通道，
     * **不足以加载官方首页**——首页要浏览器会话 cookie（见 `browserCookie`）。
     */
    cookie: string;
    /**
     * **浏览器会话 cookie**（`GET /?token=<launchToken>` 的 303 set-cookie，payload
     * `version: 1`）。官方首页的 `authorizeIndex` 只认这个版本；拿 API 凭据请求
     * 首页恒未授权。控制台代理必须用它拉首页与静态资源。
     *
     * 可选：旧对端不发该字段 → 控制台首页通道明确不可用（不拿 API 凭据顶替，
     * 那只会得到一个恒失败的页面）。
     */
    browserCookie?: string;
}
export type ClientFrame = HelloFrame | CredentialFrame;
export interface ServerHelloFrame {
    type: "server_hello";
    homeBinding: HomeBinding;
    bindingProtocol: number;
    publicKeySpki: string;
    nonce: string;
    expiry: number;
    hostId: string;
    epoch: string;
    signature: string;
    decisionSignature: string;
    state: string;
    bindingId: string | null;
    displayCode: string | null;
    /**
     * 待批记录的**真实审批截止**（毫秒；仅 `pending_approval`，非秘密、不参与签名）。
     *
     * 有效期内同钥重连是幂等的（同一对 id/码），但 `expiry` 是**本次挑战**的新到期
     * （now+60s），记录的实际截止仍是首次那一个。Rust 侧显式带出记录截止，插件据此
     * 把到期定时器裁定在两者的**较早者**上——否则 T+55s 重连拿回来的码会显示成
     * 「还能活 60 秒」，实际 5 秒后就批不了（点了就是 AUTH_EXPIRED）。
     */
    pendingExpiresAt?: number | null;
}
export type ServerFrame = ServerHelloFrame | {
    type: "granted";
    bindingId: string;
    event?: string;
    eventSignature?: string;
} | {
    type: "revoked";
    bindingId: string;
    event?: string;
    eventSignature?: string;
} | {
    type: "error";
    error: string;
    detail: string;
};
/** 挑战 TTL（毫秒；与 Rust CHALLENGE_TTL_MS 一致）。 */
export declare const CHALLENGE_TTL_MS = 60000;
/** 一次握手尝试的结果观测。 */
export type HandshakeOutcome = {
    state: "pending_approval";
    bindingId: string;
    displayCode: string;
    expiresAtMs: number;
} | {
    state: "authorized";
    bindingId: string;
    cookieDelivered: boolean;
} | {
    state: "revoked";
    bindingId: string | null;
} | {
    state: "refused";
    reason: string;
};
export interface BindingClientOptions {
    homeBinding?: HomeBinding | ((rv: Rendezvous) => HomeBinding | undefined);
    transport: IpcTransport;
    rendezvous: RendezvousReader;
    storage: BindingStorage;
    exchange: CookieExchange;
    /**
     * 浏览器会话凭据兑换（P1-2a；可选）。缺省 = 控制台首页通道不可用。
     * 返回 null 表示兑换失败/不可用——**不拿 API 凭据顶替**。
     */
    browserExchange?: () => Promise<string | null>;
    /** 毫秒时钟（测试注入假时钟）。 */
    clock: () => number;
}
export type BindingClientState = "idle" | "pending" | "bound" | "revoked";
/**
 * 单次握手客户端（**wire 形状的单元测试面，非生产装配**）。
 *
 * `runOnce()` 每次调用开一条新连接、握手结束即按需关闭——这正是 R04/R05 判定
 * 不足的形态（待批不保活、绑定后无人读、重连换码）。**生产装配请用
 * [`BindingSession`]**（单连接、稳定待批、读循环消费撤权）。
 *
 * 保留本类的原因：T06 的四类 wire 行为（未批准不交付 / 重放换 nonce /
 * 旧代际跟随 / 撤权停止交付）在这里以最小步伐逐条可断言，且与 BindingSession
 * 共用同一套帧类型、签名消息与存储形状；删掉会同时删掉这些保证。
 */
export declare class BindingClient {
    private readonly options;
    private storage;
    private currentState;
    private lastSnapshot;
    constructor(options: BindingClientOptions);
    /** 客户端当前绑定态。 */
    get state(): BindingClientState;
    /** 本地 UI 可渲染的快照（经 webServer 路由暴露；无秘密）。 */
    snapshot(): {
        state: BindingClientState;
        bindingId: string | null;
        displayCode: string | null;
    };
    /** 显式重置身份（撤权后重新走 TOFU 的唯一路径；旧钥墓碑在 Rust 侧已拒）。 */
    resetIdentity(): Promise<void>;
    /** 一次真实握手尝试：读 rendezvous → 连接 → 签名挑战 → 按服务端决策行动。 */
    runOnce(): Promise<HandshakeOutcome>;
    /** 握手主体（连接已建立）。 */
    private handshake;
    private refuse;
    private markRevoked;
    private parseServerFrame;
    private readIdentity;
    private generateIdentity;
    private generateAndStore;
}
/**
 * 本地 UI（渲染层）可订阅的绑定态快照（宿主半区经 webServer 路由暴露；
 * 这里只声明形状）。
 */
export interface BindingStateSnapshot {
    state: BindingClientState;
    bindingId: string | null;
    displayCode: string | null;
}
/**
 * 定时器抽象（生产 = 宿主全局 `setTimeout`；测试注入可手动推进的记录型调度器，
 * 用于「零泄漏定时器」断言）。
 */
export interface BindingScheduler {
    setTimeout(run: () => void, ms: number): unknown;
    clearTimeout(handle: unknown): void;
}
export interface BindingSessionOptions {
    homeBinding?: HomeBinding | ((rv: Rendezvous) => HomeBinding | undefined);
    transport: IpcTransport;
    rendezvous: RendezvousReader;
    storage: BindingStorage;
    exchange: CookieExchange;
    /** 浏览器会话凭据兑换（P1-2a；可选）。缺省 = 控制台首页通道不可用。 */
    browserExchange?: () => Promise<string | null>;
    clock: () => number;
    /** 定时器来源（测试注入记录型调度器；缺省用全局定时器）。 */
    scheduler?: BindingScheduler;
}
/**
 * 绑定会话：**整个生命周期最多一条 IPC 连接**。
 *
 * 状态机（R04/R05 的核心；K5/M-2 后的错误码分档见下）：

 * ```
 * idle ──hello──► pending ──Granted──► bound ──Revoked/PEER_REVOKED──► revoked
 *   ▲               │                    │
 *   └──掉线退避重连──┴────────────────────┘（仅掉线重连，撤权不重连）
 * ```

 * 错误码分档（K5 修复，**这是本节最重要的一条**）：
 *
 * | 服务端回绝码 | 语义 | 插件动作 |
 * | --- | --- | --- |
 * | `DSH_PEER_REVOKED` | **永久**：本绑定已被用户撤权 | 进 `revoked`、写 identity.json 墓碑、停止兑换/交付/重连 |
 * | `DSH_AUTH_NOT_APPROVED` / 未知绑定 | **可恢复**：尚未批准、待批记录过期、并发替换 | 退回 `pending`/`idle` + 退避重连，**不写墓碑**、凭据交付路径保持可用 |
 *
 * 为什么必须分档：`gates` 与待批记录都可能在用户操作/竞争下变化，把「还没批准」
 * 当成「被永久撤销」会让插件自钉死（写墓碑后既不重连也没人调用 `resetIdentity()`），
 * 一次竞争就永久停摆。真正的永久撤权由服务端显式推的 `revoked` 帧或
 * `DSH_PEER_REVOKED` 表达。
 *
 * 三条纪律（对应审查发现）：
 *  1. **待批不换码**：待批期间连接被保留（不「握手回完就关」）；只有真掉线才
 *     退避重连，并依赖 Rust 侧「同一客户端公钥在挑战到期前幂等」拿回同一对
 *     binding_id/display_code。快照在掉线重连时**不清空**，核对码不翻动。
 *  2. **单连接**：任一时点最多一条连接；绑定后保留该连接并跑读循环消费
 *     granted/revoked 推送（旧实现绑定后无人读，撤权推送被丢弃，还每 3 秒
 *     重连一条把旧连接泄漏掉）。
 *  3. **撤权即停**：收到 `revoked` 帧、或服务端以 `DSH_PEER_REVOKED` 拒绝 →
 *     进入 revoked，停止兑换与交付、**不再重连**（不静默换绑；重新绑定必须显式
 *     resetIdentity 换新钥）。
 *
 * disposer：关连接 + 清掉所有它登记的定时器 + 停读循环；二次调用是 no-op。
 */
export declare class BindingSession {
    private readonly options;
    private storage;
    private readonly scheduler;
    /** 待批到期定时器（P1-①；连接更换/收场/释放时清理）。 */
    private pendingTimer;
    private domainTimer;
    private connection;
    private timer;
    /** 退避代数（每次成功握手清零；每次掉线 +1）。 */
    private backoffStep;
    private disposed;
    /** 一轮「连接 → 握手 → 读循环」是否仍在推进（防止同一连接被两条路径处理）。 */
    private running;
    private lastSnapshot;
    constructor(options: BindingSessionOptions);
    /** 当前绑定态（本地 UI 数据源）。 */
    get state(): BindingClientState;
    /** 本地 UI 可渲染的快照（无秘密）。 */
    snapshot(): BindingStateSnapshot;
    /** 启动会话（幂等：已启动/已释放时不再启动第二条连接）。 */
    start(): void;
    /** 卸载：关连接、清定时器、停循环。二次调用是 no-op。 */
    dispose(): void;
    /**
     * 一次「连接 → 握手 → （待批/绑定）保持并读」。
     *
     * 返回后若仍需重试，由 [`scheduleReconnect`] 排下一轮；撤权路径不再排。
     */
    private cycle;
    private runConnection;
    private watchDomain;
    private clearDomainTimer;
    /**
     * 待批到期定时器（P1-①）：挑战 expiry 一到就本地关线——readLoop 随之结束、
     * 走重连重握手；Rust 侧同钥幂等在有效期内给回同码，过期给回新码并关闭旧线。
     *
     * 加固（复审 Blocker-1）：定时器**武装在 readLoop 之前**，而批准发生在 readLoop
     * 之内（快照翻 bound、连接保留）。除了在批准分支显式清除之外，回调本身也必须
     * 双条件自检——只有「仍是当前连接」且「仍处于待批」才允许关线，否则一次到点
     * 就会误杀一条活着的已绑定连接（无谓重握手 + 重新兑换）。
     */
    private armPendingExpiry;
    private clearPendingExpiry;
    /**
     * 握手：发 hello → 验 Rust 签名 → 按决策行动。
     *
     * 只在 authorized 时兑换并交付 cookie；pending 期零凭据（纪律不变）。
     */
    private handshake;
    /**
     * 读循环：消费服务端推送直到连接结束。
     *
     * 这是 R05 的核心——绑定成功后连接**必须有人读**，否则撤权推送被丢弃、
     * 旧连接只会被下一次重连泄漏掉。读到 EOF/错误时：
     *  - 已绑定 → 视为掉线，退避重连一次（凭据与连接生死绑定，必须重新握手）；
     *  - 待批 → 同样退避重连（Rust 幂等给回同一对 id/码）；
     *  - 已撤权 → 不重连。
     */
    private readLoop;
    /**
     * 在已受信连接上兑换并交付凭据（待批连接收到 Granted 后的路径）。
     *
     * 返回是否**确实交付成功**（服务端回了 granted ack）。调用方（读循环）据此决定
     * 快照：只有 `true` 才置 bound——失败一律不得假显已绑定（K6/M-4，两端以 Rust
     * 侧「有没有 cookie」这个真值为准）。
     */
    private deliverCredential;
    /** 排下一轮重连（退避；撤权/已释放则不排）。 */
    private scheduleReconnect;
    private clearTimer;
    /** 关掉并忘记这条连接（幂等；只有当前连接被忘记时不动别条）。 */
    private clearConnection;
    private parseServerFrame;
    private markRevoked;
    private readIdentity;
    private generateIdentity;
    private generateAndStore;
}
