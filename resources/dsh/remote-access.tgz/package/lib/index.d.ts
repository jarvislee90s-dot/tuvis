/**
 * 宿主半区（DSH Desktop `desktop` profile 内的 Cordis 插件）。
 *
 * 注册形态：cordis.patch.yml 以 `insert: {id, name}` 把本包挂进宿主入口表，
 * 宿主 Loader 导入包默认导出并应用为插件。本半区注入宿主服务
 * `connection`（API 连接）与 `webServer`（路由注册），并以「apply 返回
 * disposer」的 Cordis effect 形态保证卸载时彻底清理。
 *
 * T06：在 health 之上追加 `GET /tuvis-remote/binding-state`（本地授权卡数据源），
 * 并按**运行时门**启动绑定会话（读 rendezvous → 主动连接兔维斯 → 签名挑战 →
 * 批准后经注入兑换交付 owner Cookie）。启动门（保守激活，防止在非真实宿主/
 * 测试环境里自发外连）：
 *   ① `TUVIS_DSH_BINDING=enable` 环境变量（G1 实机探测/验证通道），或
 *   ② 注入的 `connection` 服务暴露可调用的 `authenticatedUrl`（Mac 补探测 §4.1
 *      实测确认：真实宿主恒有该函数，arity=1）。
 * 两门皆关时只注册路由（快照 idle），**绝不**连接兔维斯。
 *
 * 会话形态见 [`BindingSession`]（R04/R05）：稳定待批 + 单连接 + 读循环消费撤权。
 *
 * 兑换（/connect）按 Mac 补探测 §4.1/§4.2 的实测形状真实实现（见
 * [`createHostExchange`]）：真机上的最终确认仍属 G1-Mac，但代码不是占位。
 *
 * **访问边界（N1）**：本半区自注册的每条路由都必须自带门禁（宿主不代挡，
 * 实测见报告 §3.5）；且**没有任何授权写入口**——批准只在兔维斯 Tauri IPC。
 */
import type { Plugin } from "@deepseek-ai/cordis";
import type { WebRoute, WebServer } from "@deepseek-ai/dsh-host-webserver";
import { type BindingStorage, type CookieExchange, type Rendezvous, type RendezvousReader } from "./auth.js";
export type { WebRoute };
/** 本插件需要的宿主上下文最小面（真实 Cordis Context 在运行期满足该结构）。 */
export interface HostContext {
    webServer: WebServer;
    /** 宿主连接服务（`inject: ["connection"]`；兑换注入缝的载体）。 */
    connection?: unknown;
    profileContext?: {
        home: string;
        dir: string;
        name: string;
    };
}
export declare const name = "@tuvis/dsh-remote-access";
/** 依赖的宿主服务：connection（授权交换用）+ webServer（路由注册）。 */
export declare const inject: string[];
/** 兔维斯远控在本机 WebServer 上的路由前缀（exact 命名空间，与 /remote 聊天路由无关）。 */
export declare const ROUTE_PREFIX = "/tuvis-remote";
/** 绑定态路由路径（本地授权卡数据源；相对路径由 client 半区 fetch）。 */
export declare const BINDING_STATE_PATH = "/tuvis-remote/binding-state";
declare function deriveRendezvousPath(): string;
/**
 * 生产 rendezvous 路径（导出供测试与诊断；`TUVIS_DSH_STATE_DIR` 同义约定见上）。
 */
export { deriveRendezvousPath };
/**
 * 候选记录 + 来源（H05 审查 I3/I4/M1 的路由依据）：
 *  - `"legacy"` = 根 `rendezvous.json`（旧单例域；身份走旧 profile 存储路径，逐字保留）；
 *  - `"instance"` = `instances/<id>/rendezvous.json`（实例域；身份按 hostId 分段）。
 */
export interface RendezvousCandidate {
    record: Rendezvous;
    origin: "legacy" | "instance";
    /** 实例域目录名（= 登记 ID；记录 hostId 必须与其一致——M1）。 */
    dirName?: string;
}
/**
 * 实例作用域 rendezvous 候选集（H05 按实例段）：legacy 单文件 +
 * `instances/<instanceId>/rendezvous.json` 全扫。目录名只接受 32 位十六进制
 * 注册形态（实例 ID 的派生形状；防路径遍历/防任意目录名注入）。缺 `instances/`
 * 目录 = 只有 legacy 单文件（旧单例布局照常可读）。
 */
export declare function rendezvousCandidatePaths(stateDir: string): string[];
/**
 * 按宿主 PID 选定本实例的 rendezvous（H05 路由核心）：插件与宿主同进程
 * （OS peercred 核验依赖这一点），`processIdentity.pid` 即宿主进程 PID——
 * 与本进程 PID 唯一对应的那份记录就是本实例的授权域。零匹配/多匹配 →
 * `null`（fail-closed，不猜）。已停用（retired）与 hostId 不合规的记录不参与。
 */
export declare function selectRendezvousForPid(records: Rendezvous[], pid: number): Rendezvous | null;
/**
 * 生产 rendezvous 读取器（H05 按实例路由）：扫候选集（retired/非法 hostId 已滤）
 * → 按本进程 PID（= 宿主 PID）选定本实例记录。A/B 实例各自连接各自的授权域，
 * 互不串线；「先 legacy 后选择」经 retired 交接标记显式换线。
 */
export declare function instanceRendezvousReader(stateDir?: string): RendezvousReader;
/**
 * 实例作用域身份存储（H05 审查 I4 重构·按**选定记录的来源**路由）：
 *  - 选定 legacy 记录（无选择/未交接的旧单例域）→ **旧 profile 存储路径逐字保留**
 *    （`<DSH_HOME>/profiles/desktop/tuvis-remote/identity.json`）——旧钥/信任锚/
 *    撤权墓碑原样可用，绝不因升级触发重新授权；
 *  - 选定实例记录 → `<DSH_HOME>/tuvis-remote/<hostId>/identity.json`，实例槽为空
 *    时执行上面的显式迁移（同钥、清域关系标记；撤权证据命中则拒绝——不迁已撤钥，
 *    见 [`migrateLegacyIdentity`]）。
 *
 * 未选到 rendezvous（未发布/多义/全部停用）→ 读 null、写明确失败（fail-closed）。
 */
export declare function instanceFileStorage(dshHome: string, stateDir: string, pid?: number): BindingStorage;
/**
 * 兑换失败的类型化错误：只暴露**阶段名**，绝不携带 token / cookie / 对端 URL。
 *
 * 为什么单独一个类：调用方（绑定会话）只需按阶段决定重试与否；同时保证任何
 * `console.error(err)` / 栈打印都不可能把授权材料带出去（§4.2 的 token 查询串
 * 与 Cookie 值都是凭据级秘密）。
 */
export declare class CookieExchangeError extends Error {
    readonly stage: CookieExchangeStages;
    constructor(stage: CookieExchangeStages, detail: string);
}
/** 兑换阶段（诊断用；每个 stage 对应一处可观测的契约偏离）。 */
export type CookieExchangeStages = "authenticated-url" | "connect-request" | "connect-status" | "set-cookie";
/** 宿主 WebServer 上兑换所需的最小面（官方 `ctx.webServer`）。 */
export interface ExchangeWebServer {
    readonly protocol: "http:" | "https:";
    readonly port: number | undefined;
}
/**
 * 真实 Cookie 兑换（报告 §4.1/§4.2 的实测形状，不再是占位）。
 *
 * 链路：
 *  1. 由 `ctx.webServer` 的 protocol+port 拼出**绝对** origin
 *     （官方 Desktop 宿主同款：`${protocol}//127.0.0.1:${port}`）；
 *  2. `connection.authenticatedUrl(origin)`（arity=1，入参必须是可 `new URL()` 的
 *     绝对 URL；返回 `http://127.0.0.1:<port>/?token=<43 字符>`）；
 *  3. `GET <origin>/connect?token=<T>&interactions=answer`，**强制
 *     `redirect: "manual"`**——自动跟随会把 302 变成 200 页面并丢掉 `set-cookie`
 *     的原始形态；
 *  4. 断言 302，取 `set-cookie` 里 `dsh-auth-*` 的完整 `name=value`（cookie 只在
 *     内存里活着，随它那条 mux socket 生死）。
 *
 * 任何偏离都抛 [`CookieExchangeError`]（带阶段，不带秘密）。本路径的**真机**
 * 验证仍待 G1-Mac（Desktop 宿主上重跑同一形状），但代码是真实实现而非占位。
 *
 * @param connection - 宿主连接服务（`inject: ["connection"]`）。
 * @param webServer - 宿主 WebServer（取 protocol/port 拼 origin）。
 * @param fetchImpl - 注入的 fetch（测试注入假件；生产走宿主全局 fetch）。
 */
export declare function createHostExchange(connection: unknown, webServer: ExchangeWebServer, fetchImpl?: typeof fetch): CookieExchange;
/**
 * 浏览器会话凭据兑换：`GET /?token=<launchToken>` → 303 + 浏览器 cookie。
 *
 * 为什么必须单独一趟（P1-2a）：官方 `authorizeIndex` 只接受 payload
 * `version: 1` 的**浏览器** cookie，而 `/connect` 签的是 `version: 2` 的 **API
 * operator** 凭据。两者不可互换——拿 API 凭据请求首页恒未授权，控制台会得到一个
 * 打不开的页面。两个入口用的是同一个 launch token（`authenticatedUrl` 产出），
 * 因此这里复用同一条 token 获取逻辑，只换请求路径与期望的重定向码。
 *
 * 失败语义：**不抛**（返回 null）。首页凭据缺失时控制台的 IPC/API 通道仍然可用，
 * 调用方据此把「首页」这条能力如实标为不可用，而不是让整个绑定失败。
 */
export declare function createBrowserCookieExchange(connection: unknown, webServer: ExchangeWebServer, fetchImpl?: typeof fetch): () => Promise<string | null>;
/** 绑定循环是否允许启动（见文件头「启动门」）。 */
export declare function bindingAutoStartEnabled(ctx: HostContext): boolean;
/**
 * 插件主体：注册路由 + （过门时）启动绑定会话，返回 disposer。
 *
 * 必须是箭头函数：Cordis 用 isConstructor 分派插件形态，function 声明
 * 可被 new（有 [[Construct]]），会被误当类插件走构造路径、丢掉返回的
 * disposer（dispose 测试抓获过这一真实缺陷）。
 */
export declare const apply: (ctx: HostContext) => (() => void);
declare const plugin: Plugin.Object;
export default plugin;
