/**
 * 本机授权 IPC 传输抽象（T06）。
 *
 * 可注入（[`IpcTransport`]）：测试用内存/假传输，生产用 Node 内置 `node:net`
 * （macOS/Linux = Unix domain socket 路径；Windows = 命名管道名——DSH Desktop
 * 的 Node 运行时两种地址形态都能直连）。帧协议与 Rust 侧一致：NDJSON，一行一帧。
 */
/** 单条连接（客户端视角；一行一帧 NDJSON）。 */
export interface IpcConnection {
    send(frame: string): Promise<void>;
    recv(): Promise<string>;
    close(): void;
    readonly closed: boolean;
}
/** 传输工厂：按 rendezvous 里的 address 建立连接。 */
export interface IpcTransport {
    connect(address: string): Promise<IpcConnection>;
}
/** 帧上限护栏（与 Rust local_ipc::MAX_FRAME_BYTES 一致）。 */
export declare const MAX_FRAME_BYTES: number;
/** 生产传输：node:net 直连（UDS 路径或命名管道名；仅本机回环面）。 */
export declare class NodeIpcTransport implements IpcTransport {
    connect(address: string): Promise<IpcConnection>;
}
