/**
 * 逐路由访问门禁（N1）——官方围栏语义的插件侧复刻。
 *
 * **为什么必须自带**（Mac 补探测报告 §3.5 实测）：官方认证与 Host/Origin 围栏
 * 只装在 `dsh-client-connection` 自己注册的路径面上（`/`、`/connect`、`/api/*`、
 * mux）；经 `webServer.register` 自注册的插件路由**不继承**任何门禁——伪装
 * Host/Origin 的请求照样 200。同一份报告 §4.4/§11.3 又用 Desktop 宿主的单变量
 * 矩阵定死了官方判据，因此本模块逐条复刻该判据（而不是另发明一套更松的）：
 *
 * | 条件 | 判据（与 §11.3 逐格对应） |
 * | --- | --- |
 * | Host | 解析出的**主机名**必须是回环字面量：127.0.0.0/8、`::1`（含 `[::1]`）、`localhost`；**端口不参与判定** |
 * | Origin 存在 | 其 authority 必须与 Host 头**逐字相同**（含端口、大小写按字面）；`null` 或非绝对 URL → 拒 |
 * | Origin 缺失 | 放行（浏览器顶层导航不带 Origin）——此时只受 Host 回环约束 |
 * | sec-fetch-site | `cross-site` → 拒；其余（`same-origin`/`same-site`/`none`/缺失）不额外拦 |
 * | 代理头 | `X-Forwarded-*` **不参与**判定（与官方一致） |
 *
 * **已知限度（如实申报，不夸大）**：Host 判定不校验端口、也不要求等于绑定字面量，
 * 因此它**不是** DNS-rebinding 的完整防线——与官方围栏同一限度。兔维斯侧真正
 * 的连接目标钉定在 Rust 传输层（只连已验证的回环 authority）。本门禁的职责是
 * 让「插件路由比宿主更松」这个差异消失，并拦住跨源页面的读取尝试。
 *
 * **不变量**：本模块只做**读**判定。插件路由不得新增任何授权写入口——批准
 * 永远在兔维斯 Tauri IPC 侧（见 index.ts 的路由表注释）。
 */
/** 门禁判定结果（拒绝时只带固定短原因，绝不回声攻击者输入）。 */
export type FenceVerdict = {
    allowed: true;
} | {
    allowed: false;
    reason: string;
};
/** 请求头最小面（node 的 `req.headers` 已小写化；此处只取判定需要的键）。 */
export interface FenceHeaders {
    host?: string | undefined;
    origin?: string | undefined;
    "sec-fetch-site"?: string | undefined;
}
/**
 * 对一次请求做门禁判定。
 *
 * @param headers - 至少含 `host`（HTTP/1.1 必有；HTTP/1.0 缺失即拒）。
 * @returns 放行或带固定短原因的拒绝。
 */
export declare function fenceRequest(headers: FenceHeaders): FenceVerdict;
